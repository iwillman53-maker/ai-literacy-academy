강의 홈페이지 템플릿 (수강생·강의자용)
=====================================
내 강의의 안내 페이지(홈)를 만드는 도구 상자입니다.
"틀은 그대로, 바꾸는 것은 course.json 하나" 가 원칙입니다.

[들어 있는 파일 5개]
 course.json            바꾸는 칸이 있는 파일 (메모장으로 엽니다. 짧습니다)
 landing-template.html  홈의 디자인 틀 (고치지 않습니다)
 make_landing.py        Claude 가 홈을 만들 때 쓰는 도구 (열거나 고칠 필요 없습니다)
 caricature.jpg         강사 사진 자리 (※ 내 사진·캐리커처로 바꿔 넣으세요)
 README.txt             지금 보는 안내문

[1단계] 압축 풀기
 zip 안에서 바로 열지 말고, 마우스 오른쪽 → "모두 압축 풀기"를 한 뒤
 생긴 폴더(강의홈-템플릿)를 바탕화면에 두세요.

[2단계] 내 사진 바꾸기 (선택, 권장)
 caricature.jpg 를 내 사진이나 캐리커처로 바꿉니다.
 - 파일 이름은 반드시 caricature.jpg 그대로 (같은 이름으로 덮어쓰기)
 - 세로로 긴 그림이 잘 어울립니다. (예: 가로 430 x 세로 840 정도)

[3단계] course.json 고치기 — 따옴표(") 안의 글자만 바꿉니다
 course.json 을 오른쪽 클릭 → 연결 프로그램 → 메모장. 따옴표와 쉼표는 지우지 마세요.

  ① 과목·제목·소속   course(과목명) · org(소속) · title_plain(제목) · subtitle(부제)
                     ※ 링크 미리보기 제목은 "과목명 | 소속" 으로 나옵니다
  ② 일시·장소·강사   info 안의 글자 (줄을 지우면 그 칸이 안 나옵니다)
  ③ 키워드·강의 내용  chips(키워드) · parts(부 제목과 항목들)
  ④ 파일 이름 3칸    page · slides_url · og_image
        page        이 홈 파일의 이름           예: pa101.html
        slides_url  연결할 슬라이드 파일 이름    예: pa101-slides.html
        og_image    링크 미리보기 그림 이름      예: pa101-og.jpg
        → 과목마다 서로 다른 이름을 쓰세요. (같은 이름이면 앞의 과목을 덮어씁니다)
  ※ domain 은 Vercel 에 올린 뒤 알게 되는 내 사이트 주소로 한 번만 바꿉니다
     (예: https://내이름-lectures.vercel.app)

[4단계] Claude 에게 홈 만들게 하기 (내 컴퓨터에 설치할 프로그램은 없습니다)
 1) claude.ai 새 대화에서 입력창의 ＋ 를 눌러 파일 4개를 첨부합니다.
      course.json, landing-template.html, make_landing.py, caricature.jpg
 2) 아래 문장을 붙여 넣고 보냅니다. (파일 이름은 course.json 의 page · og_image 와 같게)
      첨부한 강의 홈 템플릿으로 홈 페이지를 만들어 줘. make_landing.py 를 실행해서
      course.json 값 그대로, 파일 이름은 pa101.html, 미리보기 이미지는 pa101-og.jpg 로.
 3) Claude 가 돌려주는 pa101.html 과 pa101-og.jpg 두 파일을 한 폴더에 저장합니다.
    (홈 파일과 링크 미리보기 그림이 함께 만들어집니다)

[5단계] 올리기
 만들어진 파일들을 GitHub 저장소에 올리면 (Add file → Upload files → Commit)
 Vercel 이 1~2분 안에 자동으로 공개합니다.

[더 꾸미고 싶을 때] — 필요할 때만 course.json 에 한 줄씩 덧붙이세요 (없어도 홈은 만들어집니다)
  "kicker": "제목 위 한 줄"            "title_html": "큰 <em>강조</em> 제목"
  "promises": [["이해","설명"], ["적용","설명"]]   → '오늘의 약속' 칸이 생깁니다
  "quote": "한 문장", "quote_sub": "부연"          → 큰 문구 칸이 생깁니다
  "instructor": {"desc": ["소개 1줄", "소개 2줄"]}  → 강사 이름 아래 소개가 생깁니다
  (줄 끝에 쉼표를 붙이고, 마지막 항목 뒤에는 붙이지 않습니다)

[잘 안 될 때]
 - 따옴표(") 나 쉼표(,) 를 지운 경우 → "course.json 의 ○번째 줄" 이라는 메시지가 나옵니다. 그 줄 근처를 확인하세요.
 - 처음으로 돌아가고 싶으면 이 zip 을 다시 풀어 새 course.json 을 쓰세요.
 - 틀린 곳은 만들어진 홈 파일을 고치지 말고 course.json 을 고쳐 다시 만드세요.

만든 곳: AI교수 나병인 · 강의 공장 (자유롭게 쓰고 고쳐 쓰셔도 됩니다)
