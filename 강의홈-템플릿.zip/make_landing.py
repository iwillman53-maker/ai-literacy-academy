#!/usr/bin/env python3
"""강의 홈페이지 만들기: course.json 의 값만 바꾸면 landing-template.html 로 홈 페이지(.html)를 만들어 줍니다.

사용법 (같은 폴더에서):
    python make_landing.py course.json
    (Mac/리눅스는 python3 make_landing.py course.json)

-> course.json 의 "page" 이름(예: pa101.html) 파일이 같은 폴더에 만들어집니다.
-> caricature.jpg(내 사진·캐리커처)가 같은 폴더에 있으면 홈 파일 안에 자동으로 들어갑니다.
-> course.json 에 적지 않은 항목은 기본값으로 채웁니다. (README 의 '더 꾸미고 싶을 때' 참고)
"""
import base64, html, json, os, sys

here = os.path.dirname(os.path.abspath(__file__))
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, 'course.json')
e = html.escape

def stop(msg):
    print('\n[멈춤] ' + msg)
    sys.exit(1)

try:
    c = json.load(open(src, encoding='utf-8'))
except FileNotFoundError:
    stop(f'{src} 파일을 찾을 수 없습니다. 이 프로그램과 같은 폴더에서 실행했는지 확인하세요.')
except json.JSONDecodeError as ex:
    stop(f'course.json 의 {ex.lineno}번째 줄 근처에 따옴표(") 나 쉼표(,) 가 빠졌거나 지워졌습니다.\n'
         '     바꾼 글자 앞뒤의 따옴표와 줄 끝 쉼표를 확인하세요. (마지막 항목 뒤에는 쉼표를 붙이지 않습니다)')

need = ['page', 'slides_url', 'og_image', 'domain', 'course', 'org', 'title_plain', 'parts']
miss = [k for k in need if k not in c]
if miss:
    stop('course.json 에서 다음 항목이 지워졌습니다: ' + ', '.join(miss))


# ---- 링크 미리보기 그림(1200x630) 만들기 ---------------------------------------
def make_og(path, course, org, title, subtitle, photo):
    """카톡·메신저에 주소를 붙였을 때 보이는 그림을 만듭니다. (Pillow 가 있을 때만)"""
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print('[안내] 링크 미리보기 그림은 건너뜁니다. 만들려면 터미널에서  pip install pillow  를 한 번 실행한 뒤 다시 실행하세요.')
        print('       (또는 Claude 에게 "미리보기 이미지도 만들어 줘" 라고 요청해도 됩니다)')
        return
    cands = [
        ('C:/Windows/Fonts/malgunbd.ttf', 0), ('C:/Windows/Fonts/malgun.ttf', 0),
        ('/System/Library/Fonts/AppleSDGothicNeo.ttc', 0), ('/Library/Fonts/AppleGothic.ttf', 0),
        ('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc', 1), ('/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf', 0),
    ]
    fp = next(((f, i) for f, i in cands if os.path.exists(f)), None)
    if not fp:
        print('[안내] 한글 글꼴을 찾지 못해 링크 미리보기 그림은 건너뜁니다.')
        return
    def font(size):
        return ImageFont.truetype(fp[0], size, index=fp[1])
    W, H = 1200, 630
    im = Image.new('RGB', (W, H), '#0E1013')
    d = ImageDraw.Draw(im)
    d.ellipse((620, -260, 1380, 500), fill='#17140A')           # 은은한 노란 빛
    d.rectangle((0, 0, 14, H), fill='#F6C744')
    # 사진 (오른쪽)
    if photo and os.path.exists(photo):
        ph = Image.open(photo).convert('RGB')
        th = 500
        ph = ph.resize((int(ph.width * th / ph.height), th))
        px, py = W - 70 - ph.width, (H - th) // 2
        d.rounded_rectangle((px - 10, py - 10, px + ph.width + 10, py + th + 10), 24, fill='#F6C744')
        im.paste(ph, (px, py))
        text_w = px - 60 - 70
    else:
        text_w = W - 140
    x = 70
    d.text((x, 70), course, font=font(40), fill='#F6C744')
    # 제목: 칸 너비에 맞춰 줄바꿈, 글자 크기 자동 조절
    words = title.split()
    for size in (92, 82, 72, 64, 56, 48):
        f = font(size); lines = []; cur = ''
        for w in words:
            t = (cur + ' ' + w).strip()
            if d.textlength(t, font=f) <= text_w or not cur:
                cur = t
            else:
                lines.append(cur); cur = w
        lines.append(cur)
        if len(lines) <= 3 and all(d.textlength(l, font=f) <= text_w for l in lines):
            break
    y = 140
    for i, l in enumerate(lines):
        d.text((x, y), l, font=f, fill='#F4F0E6' if i < len(lines) - 1 else '#F6C744')
        y += int(size * 1.25)
    if subtitle:
        d.text((x, min(y + 14, 470)), subtitle, font=font(30), fill='#9AA3B2')
    d.text((x, H - 90), f'{course} | {org}', font=font(36), fill='#C9CFDA')
    im.save(path, quality=90)
    print('링크 미리보기 그림:', path)

# ---- 기본값 채우기 -------------------------------------------------------
title = c['title_plain']
words = title.split()
if len(words) >= 3:
    default_html = e(' '.join(words[:-2])) + ' ' + '<em>' + e(words[-2]) + '</em><br>' + e(words[-1])
elif len(words) == 2:
    default_html = e(words[0]) + ' <em>' + e(words[1]) + '</em>'
else:
    default_html = '<em>' + e(title) + '</em>'
info = {k: v for k, v in c.get('info', {}).items() if v}
teacher = info.get('강사', '')
kicker = c.get('kicker', c['course'])
footer = c.get('footer', ' · '.join(x for x in [c['course'], c['org'], teacher] if x))

# ---- 강의 구성 (parts) : {"부 제목": ["항목", ...]} 또는 예전 목록 형식 -------------
n = 0
parts_html = ''
if isinstance(c['parts'], dict):
    plist = [{'n': f'{i}부', 't': k, 'items': v} for i, (k, v) in enumerate(c['parts'].items(), 1)]
else:
    plist = c['parts']
for p in plist:
    li = ''
    for it in p['items']:
        n += 1
        li += f'<li><b>{n}</b><span>{it}</span></li>'
    parts_html += f'<article class="part"><div class="pn">{e(p["n"])}</div><h3>{e(p["t"])}</h3><ul>{li}</ul></article>'

# ---- 선택 구역: 적었을 때만 나옵니다 ----------------------------------------
info_sec = ''
if info:
    cells = ''.join(f'<div><b>{e(k)}</b><span>{e(v)}</span></div>' for k, v in info.items())
    info_sec = ('<section class="blk"><div class="wrap"><div class="lab">강의 안내</div>'
                f'<h2>언제, <span class="am">어디서</span></h2><div class="info">{cells}</div></div></section>')

promise_sec = ''
if c.get('promises'):
    cards = ''.join(f'<div class="pc"><b>{e(a)}</b><span>{e(b)}</span></div>' for a, b in c['promises'])
    promise_sec = ('<section class="blk"><div class="wrap">'
                   f'<div class="lab">{e(c.get("promise_label", "오늘의 약속"))}</div>'
                   f'<h2>{c.get("promise_title", "오늘 <span class=\"am\">얻어 갈 것</span>")}</h2>'
                   f'<div class="promise">{cards}</div></div></section>')

quote_sec = ''
if c.get('quote'):
    quote_sec = f'<div class="quote"><p>{c["quote"]}</p><small>{e(c.get("quote_sub", ""))}</small></div>'

pic = os.path.join(here, 'caricature.jpg')
img = ''
if os.path.exists(pic):
    img = 'data:image/jpeg;base64,' + base64.b64encode(open(pic, 'rb').read()).decode()
else:
    print('[안내] caricature.jpg 가 없어 강사 사진 없이 만듭니다.')
inst_sec = ''
if teacher:
    ins = c.get('instructor', {})
    desc = '<br>'.join(e(x) for x in ins.get('desc', [])) if isinstance(ins, dict) else ''
    pic_tag = f'<img src="{img}" alt="{e(teacher)}">' if img else ''
    inst_sec = ('<section class="blk"><div class="wrap"><div class="lab">강사</div>'
                f'<div class="me">{pic_tag}<div><h3>{e(teacher)}</h3><p>{desc}</p></div></div></div></section>')

# ---- 템플릿에 끼워 넣기 -----------------------------------------------------
t = open(os.path.join(here, 'landing-template.html'), encoding='utf-8').read()
rep = {
    'TITLE_PLAIN': e(title), 'COURSE': e(c['course']), 'KICKER': e(kicker), 'SUBTITLE': e(c.get('subtitle', '')),
    'ORG': e(c['org']), 'OG_DESC': e(c.get('og_desc', '여기를 눌러 링크를 확인하세요.')),
    'DOMAIN': c['domain'].rstrip('/'), 'OG_IMAGE': c['og_image'], 'PAGE': c['page'],
    'TITLE_HTML': c.get('title_html', default_html),
    'CHIPS': ''.join(f'<span>{e(x)}</span>' for x in c.get('chips', [])),
    'SLIDES_URL': c['slides_url'], 'INFO_SECTION': info_sec, 'PROMISE_SECTION': promise_sec,
    'PARTS_LABEL': e(c.get('parts_label', '강의 구성')),
    'PARTS_TITLE': c.get('parts_title', '이렇게 <span class="am">진행합니다</span>'),
    'PARTS': parts_html, 'QUOTE_SECTION': quote_sec, 'INSTRUCTOR_SECTION': inst_sec, 'FOOTER': e(footer),
}
for k, v in rep.items():
    t = t.replace('{{' + k + '}}', v)
if '{{' in t:
    stop('채워지지 않은 항목이 있습니다. landing-template.html 을 고치지 않았는지 확인하세요.')

out = os.path.join(os.path.dirname(os.path.abspath(src)), c['page'])
open(out, 'w', encoding='utf-8').write(t)
print('만들어진 파일:', out)
make_og(os.path.join(os.path.dirname(out), c['og_image']), c['course'], c['org'], c['title_plain'], c.get('subtitle', ''), pic)
print('다음 순서: 이 파일과 슬라이드 파일, 링크 미리보기 이미지를 GitHub 저장소에 올립니다.')
