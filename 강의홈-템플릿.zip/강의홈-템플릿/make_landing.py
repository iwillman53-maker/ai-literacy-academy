#!/usr/bin/env python3
"""강의 홈페이지 만들기: course.json 의 값만 바꾸면 landing-template.html 로 홈 페이지(.html)를 만들어 줍니다.

사용법 (같은 폴더에서):
    python make_landing.py course.json
    (Mac/리눅스는 python3 make_landing.py course.json)

-> course.json 의 "page" 이름(예: pa101.html) 파일이 같은 폴더에 만들어집니다.
-> caricature.jpg(내 사진·캐리커처)가 같은 폴더에 있으면 홈 파일 안에 자동으로 들어갑니다.
"""
import base64, html, json, os, sys

here = os.path.dirname(os.path.abspath(__file__))
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, 'course.json')

def stop(msg):
    print('\n[멈춤] ' + msg)
    sys.exit(1)

try:
    c = json.load(open(src, encoding='utf-8'))
except FileNotFoundError:
    stop(f'{src} 파일을 찾을 수 없습니다. 이 프로그램과 같은 폴더에서 실행했는지 확인하세요.')
except json.JSONDecodeError as ex:
    stop(f'course.json 의 {ex.lineno}번째 줄 근처에 따옴표(") 나 쉼표(,) 가 빠졌거나 지워졌습니다.\n'
         '     바꾼 글자 앞뒤의 따옴표와 줄 끝 쉼표를 확인하세요. (마지막 항목 뒤에는 쉼표를 붙이지 않습니다)')

need = ['page', 'slides_url', 'og_image', 'domain', 'org', 'course', 'og_desc', 'kicker', 'title_plain',
        'title_html', 'subtitle', 'chips', 'promise_label', 'promise_title', 'promises', 'parts_label',
        'parts_title', 'parts', 'quote', 'quote_sub', 'instructor', 'footer']
miss = [k for k in need if k not in c]
if miss:
    stop('course.json 에서 다음 항목이 지워졌습니다: ' + ', '.join(miss))

t = open(os.path.join(here, 'landing-template.html'), encoding='utf-8').read()
e = html.escape

pic = os.path.join(here, 'caricature.jpg')
if os.path.exists(pic):
    img = 'data:image/jpeg;base64,' + base64.b64encode(open(pic, 'rb').read()).decode()
else:
    img = ''
    print('[안내] caricature.jpg 가 없어 강사 사진 없이 만듭니다.')

n = 0
parts = ''
for p in c['parts']:
    li = ''
    for it in p['items']:
        n += 1
        li += f'<li><b>{n}</b><span>{it}</span></li>'
    parts += f'<article class="part"><div class="pn">{e(p["n"])}</div><h3>{e(p["t"])}</h3><ul>{li}</ul></article>'

info = {k: v for k, v in c.get('info', {}).items() if v}
info_sec = ''
if info:
    cells = ''.join(f'<div><b>{e(k)}</b><span>{e(v)}</span></div>' for k, v in info.items())
    info_sec = ('<section class="blk"><div class="wrap"><div class="lab">강의 안내</div>'
                f'<h2>언제, <span class="am">어디서</span></h2><div class="info">{cells}</div></div></section>')

rep = {
    'TITLE_PLAIN': e(c['title_plain']), 'COURSE': e(c['course']), 'KICKER': e(c['kicker']),
    'SUBTITLE': e(c['subtitle']), 'ORG': e(c['org']), 'OG_DESC': e(c['og_desc']),
    'DOMAIN': c['domain'].rstrip('/'), 'OG_IMAGE': c['og_image'], 'PAGE': c['page'],
    'TITLE_HTML': c['title_html'], 'CHIPS': ''.join(f'<span>{e(x)}</span>' for x in c['chips']),
    'SLIDES_URL': c['slides_url'], 'INFO_SECTION': info_sec,
    'PROMISE_LABEL': e(c['promise_label']), 'PROMISE_TITLE': c['promise_title'],
    'PROMISES': ''.join(f'<div class="pc"><b>{e(a)}</b><span>{e(b)}</span></div>' for a, b in c['promises']),
    'PARTS_LABEL': e(c['parts_label']), 'PARTS_TITLE': c['parts_title'], 'PARTS': parts,
    'QUOTE': c['quote'], 'QUOTE_SUB': e(c['quote_sub']), 'CARICATURE': img,
    'INSTRUCTOR_NAME': e(c['instructor']['name']),
    'INSTRUCTOR_DESC': '<br>'.join(e(x) for x in c['instructor']['desc']),
    'FOOTER': e(c['footer']),
}
for k, v in rep.items():
    t = t.replace('{{' + k + '}}', v)
if '{{' in t:
    stop('채워지지 않은 항목이 있습니다. course.json 의 항목 이름을 지우거나 바꾸지 않았는지 확인하세요.')

out = os.path.join(os.path.dirname(os.path.abspath(src)), c['page'])
open(out, 'w', encoding='utf-8').write(t)
print('만들어진 파일:', out)
print('다음 순서: 이 파일과 슬라이드 파일, 링크 미리보기 이미지를 GitHub 저장소에 올립니다.')
