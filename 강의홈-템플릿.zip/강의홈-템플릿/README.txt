강의 홈페이지 템플릿 (수강생·강의자용)
=====================================
내 강의의 안내 페이지(홈)를 만드는 도구 상자입니다.
"틀은 그대로, 바꾸는 것은 course.json 하나" 가 원칙입니다.

[들어 있는 파일 5개]
 course.json            바꾸는 칸이 있는 파일 (메모장으로 엽니다)
 landing-template.html  홈의 디자인 틀 (고치지 않습니다)
 make_landing.py        홈을 자동으로 만들어 주는 도구
 caricature.jpg         강사 사진 자리 (※ 내 사진·캐리커처로 바꿔 넣으세요)
 README.txt             지금 보는 안내문

[1단계] 압축 풀기
 zip 안에서 바로 열지 말고, 마우스 오른쪽 → "모두 압축 풀기"를 한 뒤
 생긴 폴더(강의홈-템플릿)를 바탕화면에 두세요.

[2단계] 내 사진 바꾸기 (선택, 권장)
 caricature.jpg 를 내 사진이나 캐리커처로 바꿉니다.
 - 파일 이름은 반드시 caricature.jpg 그대로 (같은 이름으로 덮어쓰기)
 - 세로로 긴 그림이 잘 어울립니다. (예: 가로 430 x 세로 840 정도)
 - 이 그림은 홈 페이지 맨 아래 '강사 소개' 칸에 들어갑니다.

[3단계] course.json 고치기
 course.json 을 오른쪽 클릭 → 연결 프로그램 → 메모장. 따옴표(") 안의 글자만 바꿉니다.
 따옴표와 쉼표는 지우지 마세요.

  course            과목 이름        → 링크 미리보기 제목 "과목 | 소속" 에도 쓰입니다
  org               소속 이름        → 링크 미리보기 제목의 뒷부분 (예: ○○대학교, ○○초등학교)
  title_plain       큰 제목(글자만)
  title_html        큰 제목 (<em>…</em> 로 감싼 글자가 노란색으로 보입니다)
  subtitle, kicker  부제 / 제목 위 한 줄
  info              일시 · 시간 · 장소 · 대상 · 강사 (모두 비우면 '강의 안내' 칸이 사라집니다)
  chips             키워드 단어들
  promises          오늘의 약속 (제목, 설명 쌍)
  parts             강의 구성 (부 이름, 부 제목, 항목들)
  instructor, footer  강사 소개, 맨 아래 한 줄
  page / slides_url / og_image   파일 이름 3칸 (아래 설명)
  domain            내 사이트 주소 (예: https://내이름-lectures.vercel.app)
                    ※ Vercel 에서 배포한 뒤 알게 되는 내 주소로 바꿉니다

 파일 이름 3칸
  page        이 홈 파일의 이름           예: pa101.html
  slides_url  연결할 슬라이드 파일 이름    예: pa101-slides.html
  og_image    링크 미리보기 그림 이름      예: pa101-og.jpg
  → 과목마다 서로 다른 이름을 쓰세요. (같은 이름이면 앞의 과목을 덮어씁니다)

[4단계] 홈 만들기 — 방법은 둘 중 하나
 방법 A. Claude 에게 맡기기 (프로그램 설치가 필요 없습니다)
   course.json, landing-template.html, make_landing.py, caricature.jpg 4개 파일을 첨부하고
   "첨부한 강의 홈 템플릿으로 홈 페이지를 만들어 줘. course.json 값 그대로,
    파일 이름은 pa101.html, 미리보기 이미지는 pa101-og.jpg 로." 라고 요청합니다.
 방법 B. 내 컴퓨터에서 직접 만들기 (Python 이 설치된 경우)
   폴더에서 터미널(명령 창)을 열고
      python make_landing.py course.json
   → course.json 의 page 이름(예: pa101.html) 파일이 같은 폴더에 만들어집니다.
   (링크 미리보기 그림은 별도로 만들어야 합니다. 방법 A 를 쓰면 함께 만들어 줍니다.)

[5단계] 올리기
 만들어진 파일들을 GitHub 저장소에 올리면 (Add file → Upload files → Commit)
 Vercel 이 1~2분 안에 자동으로 공개합니다.

[잘 안 될 때]
 - 따옴표(") 나 쉼표(,) 를 지운 경우 → "course.json 의 ○번째 줄" 이라는 메시지가 나옵니다. 그 줄 근처를 확인하세요.
 - 고치기 전으로 돌아가고 싶으면 이 zip 을 다시 풀어 새 course.json 을 쓰세요.
 - 틀린 곳은 만들어진 홈 파일을 고치지 말고 course.json 을 고쳐 다시 만드세요.

만든 곳: AI교수 나병인 · 강의 공장 (자유롭게 쓰고 고쳐 쓰셔도 됩니다)
